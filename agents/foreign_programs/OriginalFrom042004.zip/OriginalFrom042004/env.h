/*
/       (XCS-C 1.1)
/	------------------------------------
/	Learning Classifier System based on accuracy
/
/     by Martin Butz
/     University of Wuerzburg / University of Illinois at Urbana/Champaign
/     butz@illigal.ge.uiuc.edu
/     Last modified: 09-04-2003
/
/     The default environment header - the specified functions and Macros need to be implemented in any environment/problem, XCS is applied to.
*/

#include "xcsMacros.h"

int isMultiStep();
int doNeedInputFile();

int setEnvParam(char *type, double value);
int getConditionLength();
int getGeneralType(); /* this should return the problem type: 0 = boolean problem, 1 = integers, 2 = real, 3 = nominals, 4 = mixed */
int getAttributeType(int att);
double getUpperBound(int att);
double getLowerBound(int att);

int getPaymentRange();
int getNumberOfActions();
double doAction(struct attributes *state, int action, int *correct);
void resetState(struct attributes *state);
int initEnv(FILE *fp);
void freeEnv();
void fprintEnv(FILE *outfile);

double getExactEstimate(struct condAttribute *conArray, int class, double *mad);
int getNextNiche(struct attributes *state, int type);

int do10FoldedCrossValidation(long seed); /* sets 10-folded crossvalidation test */
int doTesting(int doIt); /* determines if test set should be presented */
int nextTestState(struct attributes *state);

int getCrossPoints(int *pos);
